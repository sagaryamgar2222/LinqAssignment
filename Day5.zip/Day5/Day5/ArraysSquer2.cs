﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class ArraysSquer2
    {
        internal static void test()
        {
            Console.WriteLine("Enter the Size");
            int size = _CheackIntgerMethod(Console.ReadLine());
            int[] arr = new int[size];
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("Enter the number ");
                arr[i] = _CheackIntgerMethod(Console.ReadLine());

            }
            Console.Write("Array list: ");
            foreach (var item in arr)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
            Console.Write("Sqaure  List:");
            var Query = (from obj in arr
                             select obj * obj).ToArray();

            foreach (var item in Query)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
            Console.ReadLine();

        }
        public static int _CheackIntgerMethod(string s)
        {
            int no;
            bool b = int.TryParse(s, out no);
            if (b == true)
            { 
                return no; 
            }
            else
            {
                Console.WriteLine("please enter the only number ");
                return no= _CheackIntgerMethod(Console.ReadLine());
            
              
            }
         


        }
    }
}
