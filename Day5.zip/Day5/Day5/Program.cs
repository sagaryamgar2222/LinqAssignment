﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Program
    {

        /* Console.WriteLine("enter the count of employee");
         int count=int.Parse(Console.ReadLine());    

       String []a=new string[count];
         for (int i = 0; i < count; i++)
         {
             Console.WriteLine("enter the name: ");
             a[i] = Console.ReadLine();
         }



         var Query=(from obj in a
                  where obj.StartsWith("s")
                   select obj).ToList();

         Console.WriteLine("Main O/p");
         foreach (var item in Query)
         {
             Console.WriteLine(item);
         }*/

        static void Main(string[] args)
        {

            // ArraySqure.Squre();

            //ArraysSquer2.test();

            //Prod.Show();

            // Q2Puduct.show();
            //Q3Product.show();
            // Q5Product.show();

            //Q6Product.show();
            Q7Product.show();
        }


    }
    
}
