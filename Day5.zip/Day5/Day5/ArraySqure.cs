﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class ArraySqure
    {
        internal static void Squre()
        {
            Console.WriteLine("enter the size of Array");
            int size=int.Parse(Console.ReadLine());

           int[] a=new int[size];
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine( "enter the number");
                a[i]=int.Parse(Console.ReadLine());
            }
            var Query= (from obj in a
                      
                        select obj*obj).ToList();

            Console.WriteLine("output is");
            foreach (var item in Query)
            {
                Console.WriteLine(item);
            }
            
        }
    }
}
