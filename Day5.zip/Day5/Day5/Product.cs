﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Product
    {
        public String  Name { get; set; }
        public String Brand { get; set; }
        public int price { get; set; }


    }

    public class Prod
    {
        internal static void Show()
        {
            Console.WriteLine("Enter the cout of products");

            int cnt = ValidMethod._CheackIntgerMethod(Console.ReadLine());

            List<Product> pList = new List<Product>();

            for (int i = 0; i < cnt; i++)
            {
                Console.WriteLine("Enter product details: Brand , product Name, price");
                pList.Add(new Product { Brand = Console.ReadLine(), Name = Console.ReadLine(), price = ValidMethod._CheackIntgerMethod(Console.ReadLine()) });

            }
            Console.WriteLine("Enter the input to search");
            String s=Console.ReadLine();

            var QuerySyntax = (from pli in pList
                               where pli.Name.Contains(s)
                               select pli.Name).ToList();
            Console.WriteLine("The main Product is");

           
            foreach (var item in QuerySyntax)
            {
                Console.WriteLine(item);

            }
        }
    }


}
