﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandling
{
    internal class Files
    {
        internal static void show()
        {
            /* string path = @"C:\Users\sagar\Desktop\Tranings\WPF\Test.txt";

             string previousData = File.ReadAllText(path);

             int.TryParse(previousData, out int count);

             int i;
             for (i = count; i < count + 100; i++)
             {
                 Console.WriteLine(i);
             }
             File.WriteAllText(path, i.ToString());
            */
            String path =@"C:\Users\www.abcom.in\Desktop\Myfile.txt";
            Console.WriteLine("enter the ");

            File.WriteAllText(path,"sagar");
            Console.WriteLine("Data Added successfully");


           
           

            
        }
    }
}
