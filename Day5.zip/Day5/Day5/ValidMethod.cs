﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class ValidMethod
    {
        public static int _CheackIntgerMethod(string s)
        {
            int no;
            bool b = int.TryParse(s, out no);
            if (b == true)
            {
                return no;
            }
            else
            {
                Console.WriteLine("please enter the only number ");
                return no = _CheackIntgerMethod(Console.ReadLine());


            }



        }
    }
}
