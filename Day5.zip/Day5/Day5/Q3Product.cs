﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Q3Product
    {
      public static void show()
        {
            /* Console.WriteLine("Enter the cout of products");

             int cnt = ValidMethod._CheackIntgerMethod(Console.ReadLine());

             List<Product> pList = new List<Product>();

             for (int i = 0; i < cnt; i++)
             {
                 Console.WriteLine("Enter product details: Brand , product Name, price");
                 pList.Add(new Product { Brand = Console.ReadLine(), Name = Console.ReadLine(), price = ValidMethod._CheackIntgerMethod(Console.ReadLine()) });

             }
             Console.WriteLine("Enter the input to search");
             String s = Console.ReadLine();
             int min=int.MaxValue;
             var QuerySyntax = (from pli in pList
                                where pli.Brand==s && pli.price < min
                                select pli.Name).ToList();
             Console.WriteLine("The main Product is");


            foreach (var item in QuerySyntax)
             {
                 Console.WriteLine();

             }*/
            Console.WriteLine("Enetr Product Numbers");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Product Details");
            Console.WriteLine("brand Name");
            Console.WriteLine("Name");
            Console.WriteLine("price");
            List<Brand> brands = new List<Brand>();
            {
                for (int i = 0; i < num; i++)
                {
                    Console.WriteLine("Eter Details");
                    brands.Add(new Brand() { brandName = Console.ReadLine(), name = Console.ReadLine(), price = int.Parse(Console.ReadLine()) });
                }

                string s = Console.ReadLine();
               
                var result = (from b in brands
                              orderby b.price ascending
                              select b).FirstOrDefault();
                Console.WriteLine("Lowest Price");
               

                Console.WriteLine(result);
                Console.ReadLine();
            }
        }
    }
}
