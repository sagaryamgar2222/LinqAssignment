﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Q5Product
    {
        internal static void show()
        {
            List<Product> pList = new List<Product>();

            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("Enter product details brand , product name, price");
                pList.Add(new Product { Brand = Console.ReadLine(), Name = Console.ReadLine(), price = ValidMethod._CheackIntgerMethod(Console.ReadLine()) });

            }
           

            var QuerySyntax = (from pli in pList
                               orderby pli.price descending
                               select pli.price).First();
           

            Console.WriteLine(" highest price for those two brands");

            Console.WriteLine(QuerySyntax);


            Console.ReadLine();
        }
    }
}
