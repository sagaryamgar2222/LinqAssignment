﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Q7Product
    {
        internal static void show()
        {
            Console.WriteLine("Enter the number of products");
            int cnt = ValidMethod._CheackIntgerMethod(Console.ReadLine());
            List<Product> pList = new List<Product>();

            for (int i = 0; i < cnt; i++)
            {
                Console.WriteLine("Enter product details brand , product name, price");
                pList.Add(new Product { Brand = Console.ReadLine(), Name = Console.ReadLine(), price = ValidMethod._CheackIntgerMethod(Console.ReadLine())});

            }
           
            Console.WriteLine("enter limit of price from, to");

            int frm = ValidMethod._CheackIntgerMethod(Console.ReadLine());

            int too = ValidMethod._CheackIntgerMethod(Console.ReadLine());

            var QuerySyntax = (from pli in pList
                               where pli.price >= frm && pli.price <= too
                               select pli.price).ToList();
           

            Console.WriteLine(" highest price for those two brands");

            foreach (var item in QuerySyntax)
            {
                Console.WriteLine(item);

            }


            Console.ReadLine();
        }
    }
}
